<?php
/*
    Hafadz Hazmirullah
    203040022
    github.com/kangmiru/pw2021_203040022
    Pertemuan 1 (03 Februari 2021)
    mencoba PHP
*/
    echo "Hello World";
?>