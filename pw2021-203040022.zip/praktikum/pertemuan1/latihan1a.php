<?php
    for ($i=1; $i <= 3 ; $i++) { 
        for ($j=1; $j <= 3; $j++) { 
            echo "<li> pengulangan ke ($i,$j)";

        }
        ;
    }
?>